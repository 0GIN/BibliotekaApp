using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Security.Claims;


namespace biblioteka
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
        
            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }

    public class DatabaseController : ControllerBase
    {
        private readonly string databasePath = "Data Source=biblioteka.db";
        private readonly string jwtSecret = "super_secret_key_12345678901234567890123456789012";
        
        [HttpPost("create-database")]
        public IActionResult CreateDatabase()
        {
            try
            {
                Console.WriteLine(DateTime.UtcNow+ " Creating database...");
                using (var connection = new SqliteConnection(databasePath))
            {
                int count = 0;
                connection.Open();
                string query = @"CREATE TABLE IF NOT EXISTS users(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                login TEXT UNIQUE,
                password TEXT,
                name TEXT,
                surname TEXT,
                city TEXT,
                post_number TEXT,
                street TEXT,
                property_number TEXT,
                apartment_number INTEGER,
                pesel TEXT UNIQUE,
                date_of_birth TEXT,
                sex TEXT,
                email TEXT UNIQUE,
                phone_number TEXT,
                forgotten BOOLEAN DEFAULT 0,
                access_level INTEGER DEFAULT 0,
                temp_password TEXT)";
                using (var command = new SqliteCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }
                count++;
                Console.WriteLine("TABLE users created "+count+"/7");

                query = @"CREATE TABLE IF NOT EXISTS authors(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT)";
                using (var command = new SqliteCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }
                count++;
                Console.WriteLine("TABLE authors created "+count+"/7");

                query = @"CREATE TABLE IF NOT EXISTS categories(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT)";
                using (var command = new SqliteCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }
                count++;
                Console.WriteLine("TABLE categories created "+count+"/7");

                query = @"CREATE TABLE IF NOT EXISTS books(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT,
                author_id INTEGER,
                category_id INTEGER,
                isbn TEXT UNIQUE,
                publish_date INTEGER)";
                using (var command = new SqliteCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }
                count++;
                Console.WriteLine("TABLE books created "+count+"/7");

                query = @"CREATE TABLE IF NOT EXISTS book_copies(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                book_id INTEGER,
                status TEXT)";
                using (var command = new SqliteCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }
                count++;
                Console.WriteLine("TABLE book_copies created "+count+"/7");

                query = @"CREATE TABLE IF NOT EXISTS loans(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                book_copy_id INTEGER,
                loan_date TEXT,
                return_date TEXT,
                status TEXT)";
                using (var command = new SqliteCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }
                count++;
                Console.WriteLine("TABLE loans created "+count+"/7");

                query = @"CREATE TABLE IF NOT EXISTS reservations(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                book_id INTEGER,
                reservation_date TEXT,
                status TEXT)";
                using (var command = new SqliteCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }
                count++;
                Console.WriteLine("TABLE reservations created "+count+"/7");
            }
                return Ok("Database created successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost("add-user")]
        public IActionResult AddUser([FromBody] UserDto user)
        {
            try
            {
                using (var connection = new SqliteConnection(databasePath))
                {
                    connection.Open();
                    string query = @"INSERT INTO users (login, password, name, surname, city, post_number, street, property_number, apartment_number, pesel, date_of_birth, sex, email, phone_number) 
                                     VALUES (@login, @password, @name, @surname, @city, @postNumber, @street, @propertyNumber, @apartmentNumber, @pesel, @dateOfBirth, @sex, @Email, @phoneNumber)";
                    using (var command = new SqliteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@login", user.Login);
                        command.Parameters.AddWithValue("@password", user.Password);
                        command.Parameters.AddWithValue("@name", user.Name);
                        command.Parameters.AddWithValue("@surname", user.Surname);
                        command.Parameters.AddWithValue("@city", user.City);
                        command.Parameters.AddWithValue("@postNumber", user.PostNumber);
                        command.Parameters.AddWithValue("@street", user.Street);
                        command.Parameters.AddWithValue("@propertyNumber", user.PropertyNumber);
                        command.Parameters.AddWithValue("@apartmentNumber", user.ApartmentNumber);
                        command.Parameters.AddWithValue("@pesel", user.Pesel);
                        command.Parameters.AddWithValue("@dateOfBirth", user.DateOfBirth.ToString("yyyy-MM-dd"));
                        command.Parameters.AddWithValue("@sex", user.Sex.ToString());
                        command.Parameters.AddWithValue("@Email", user.Email);
                        command.Parameters.AddWithValue("@phoneNumber", user.PhoneNumber);
                        command.ExecuteNonQuery();
                    }
                }
                Console.WriteLine(DateTime.UtcNow +" User added successfully.");
                return Ok("User added successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginDto loginDto)
        {
            try
            {
                using (var connection = new SqliteConnection(databasePath))
                {
                    connection.Open();
                    string query = @"SELECT id, forgotten, access_level FROM users WHERE login = @login AND (password = @password OR temp_password = @password)";
                    using (var command = new SqliteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@login", loginDto.Login);
                        command.Parameters.AddWithValue("@password", loginDto.Password);
                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int userId = reader.GetInt32(0);
                                int accessLevel = reader.GetInt32(2);
                                string login = loginDto.Login;
                                bool forgotten = reader.GetInt32(1) == 1;
                                bool recovery = false;

                                // Sprawdź czy logowanie hasłem tymczasowym
                                string tempPassword = null;
                                using (var tempConn = new SqliteConnection(databasePath))
                                {
                                    tempConn.Open();
                                    string tempQuery = "SELECT temp_password FROM users WHERE login = @login";
                                    using (var tempCmd = new SqliteCommand(tempQuery, tempConn))
                                    {
                                        tempCmd.Parameters.AddWithValue("@login", loginDto.Login);
                                        var result = tempCmd.ExecuteScalar();
                                        tempPassword = result != DBNull.Value ? result as string : null;
                                    }
                                }
                                if (!forgotten)
                                {
                                    if (!string.IsNullOrEmpty(tempPassword) && tempPassword == loginDto.Password)
                                    {
                                        recovery = true;
                                    }
                                    Console.WriteLine(DateTime.UtcNow + " ["+userId+"] "+  "User login successfully: " + login);
                                    string token = GenerateToken(userId, accessLevel);
                                    return Ok(new { token, forgotten, recovery });
                                }
                                else
                                {
                                    Console.WriteLine(DateTime.UtcNow +" User is forgotten: " + login);
                                    throw new Exception("User is forgotten.");
                                    
                                }
                            }
                            else
                            {
                                Console.WriteLine(DateTime.UtcNow +" Failed login attempt: " + loginDto.Login);
                                throw new Exception("Invalid login credentials.");
                                
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return StatusCode(401, ex.Message);
                
            }
        }
        
        private string GenerateToken(int userId, int accessLevel)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(jwtSecret);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim("userId", userId.ToString()),
                    new Claim("accessLevel", accessLevel.ToString())
                }),
                Expires = DateTime.UtcNow.AddHours(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        [HttpPost("logout/{userId}")]
        public IActionResult Logout(int userId)
        {
            try
            {
                Console.WriteLine(DateTime.UtcNow +" user: ["+userId+"] logged out successfully.");
                return Ok("User logged out successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost("forget-user/{userId}")]
        public IActionResult ForgetUser(int userId)
        {
            try
            {
                using (var connection = new SqliteConnection(databasePath))
                {
                    connection.Open();
                    string query = @"UPDATE users SET forgotten = 1 WHERE id = @userId";
                    using (var command = new SqliteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@userId", userId);
                        command.ExecuteNonQuery();
                    }
                }
                Console.WriteLine(DateTime.UtcNow + " User forgotten successfully.");
                return Ok("User forgotten successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet("get-all-users")]
        public IActionResult GetAllUsers()
        {
            try
            {
                var users = new List<object>();
                using (var connection = new SqliteConnection(databasePath))
                {
                    connection.Open();
                    string query = @"SELECT id, login, password, name, surname, city, post_number, street, property_number, apartment_number, pesel, date_of_birth, sex, email, phone_number, forgotten, access_level, temp_password
                                     FROM users WHERE forgotten = 0";
                    using (var command = new SqliteCommand(query, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var user = new
                                {
                                    Id = reader.GetInt32(0),
                                    Login = reader.GetString(1),
                                    Password = reader.GetString(2),
                                    Name = reader.GetString(3),
                                    Surname = reader.GetString(4),
                                    City = reader.GetString(5),
                                    PostNumber = reader.GetString(6),
                                    Street = reader.GetString(7),
                                    PropertyNumber = reader.GetString(8),
                                    ApartmentNumber = reader.GetInt32(9),
                                    Pesel = reader.GetString(10),
                                    DateOfBirth = reader.GetString(11),
                                    Sex = reader.GetString(12),
                                    Email = reader.GetString(13),
                                    PhoneNumber = reader.GetString(14),
                                    Forgotten = reader.GetInt32(15) == 1,
                                    AccessLevel = reader.GetInt32(16),
                                    temp_password = reader.IsDBNull(17) ? null : reader.GetString(17)
                                };
                                users.Add(user);
                            }
                        }
                    }
                }
                return Ok(users);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet("find-user-by-login/{login}")]
        public IActionResult FindUserByLogin(string login)
        {
            try
            {
                using (SqliteConnection connection = new SqliteConnection(databasePath))
                {
                    connection.Open();
                    string query = @"SELECT id, login, name, surname, city, post_number, street, property_number, apartment_number, pesel, date_of_birth, sex, email, phone_number, forgotten 
                                    FROM users WHERE login = @login AND forgotten = 0";
                    using (SqliteCommand command = new SqliteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@login", login);
                        using (SqliteDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())//czytelność
                            {
                                var user = new
                                {
                                    id = reader.GetInt32(0),
                                    login = reader.GetString(1),
                                    name = reader.GetString(2),
                                    surname = reader.GetString(3),
                                    city = reader.GetString(4),
                                    postNumber = reader.GetString(5),
                                    street = reader.GetString(6),
                                    propertyNumber = reader.GetString(7),
                                    apartmentNumber = reader.IsDBNull(8) ? (int?)null : reader.GetInt32(8),
                                    pesel = reader.GetString(9),
                                    dateOfBirth = reader.GetDateTime(10),
                                    sex = reader.IsDBNull(11) ? (char?)null : reader.GetString(11)[0],
                                    email = reader.GetString(12),
                                    phoneNumber = reader.GetString(13)
                                };
                                return Ok(user);
                            }
                        }
                    }
                }
                return NotFound("User not found.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet("find-user-by-id/{id}")]
        public IActionResult FindUserById(int id)
        {
            try
            {
                using (SqliteConnection connection = new SqliteConnection(databasePath))
                {
                    connection.Open();
                    string query = @"SELECT id, login, name, surname, city, post_number, street, property_number, apartment_number, pesel, date_of_birth, sex, email, phone_number, forgotten 
                                    FROM users WHERE id = @id AND forgotten = 0";
                    using (SqliteCommand command = new SqliteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        using (SqliteDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                var user = new
                                {
                                    id = reader.GetInt32(0),
                                    login = reader.GetString(1),
                                    name = reader.GetString(2),
                                    surname = reader.GetString(3),
                                    city = reader.GetString(4),
                                    postNumber = reader.GetString(5),
                                    street = reader.GetString(6),
                                    propertyNumber = reader.GetString(7),
                                    apartmentNumber = reader.IsDBNull(8) ? (int?)null : reader.GetInt32(8),
                                    pesel = reader.GetString(9),
                                    dateOfBirth = reader.GetDateTime(10),
                                    sex = reader.IsDBNull(11) ? (char?)null : reader.GetString(11)[0],
                                    email = reader.GetString(12),
                                    phoneNumber = reader.GetString(13)
                                };
                                return Ok(user);
                            }
                        }
                    }
                }
                return NotFound("User not found.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
        [HttpGet("get-all-forgotten")]
        public IActionResult GetAllForgotten()
        {
            try
            {
                var users = new List<object>();
                using (var connection = new SqliteConnection(databasePath))
                {
                    connection.Open();
                    string query = @"SELECT id, login, password, name, surname, city, post_number, street, property_number, apartment_number, pesel, date_of_birth, sex, email, phone_number, forgotten 
                                     FROM users WHERE forgotten = 1";
                    using (var command = new SqliteCommand(query, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var user = new
                                {
                                    Id = reader.GetInt32(0),
                                    Login = reader.GetString(1),
                                    Password = reader.GetString(2),
                                    Name = reader.GetString(3),
                                    Surname = reader.GetString(4),
                                    City = reader.GetString(5),
                                    PostNumber = reader.GetString(6),
                                    Street = reader.GetString(7),
                                    PropertyNumber = reader.GetString(8),
                                    ApartmentNumber = reader.GetInt32(9),
                                    Pesel = reader.GetString(10),
                                    DateOfBirth = reader.GetString(11),
                                    Sex = reader.GetString(12),
                                    Email = reader.GetString(13),
                                    PhoneNumber = reader.GetString(14),
                                    Forgotten = reader.GetInt32(15) == 1
                                };
                                users.Add(user);
                            }
                        }
                    }
                }
                return Ok(users);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut("change-user-data/{userId}")]
        public IActionResult ChangeUserData(int userId, [FromBody] UserDto user)
        {
            try
            {
                using (var connection = new SqliteConnection(databasePath))
                {
                    connection.Open();
                    string query = @"UPDATE users 
                                     SET login = COALESCE(@login, login), 
                                         password = COALESCE(@password, password), 
                                         name = COALESCE(@name, name), 
                                         surname = COALESCE(@surname, surname), 
                                         city = COALESCE(@city, city), 
                                         post_number = COALESCE(@postNumber, post_number),
                                         street = COALESCE(@street, street), 
                                         property_number = COALESCE(@propertyNumber, property_number), 
                                         apartment_number = COALESCE(@apartmentNumber, apartment_number), 
                                         pesel = COALESCE(@pesel, pesel), 
                                         date_of_birth = COALESCE(@dateOfBirth, date_of_birth), 
                                         sex = COALESCE(@sex, sex), 
                                         email = COALESCE(@Email, email), 
                                         phone_number = COALESCE(@phoneNumber, phone_number),
                                         access_level = COALESCE(@accessLevel, access_level) 
                                     WHERE id = @userId";
                    using (var command = new SqliteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@userId", userId);
                        command.Parameters.AddWithValue("@login", (object?)user.Login ?? DBNull.Value);
                        command.Parameters.AddWithValue("@password", (object?)user.Password ?? DBNull.Value);
                        command.Parameters.AddWithValue("@name", (object?)user.Name ?? DBNull.Value);
                        command.Parameters.AddWithValue("@surname", (object?)user.Surname ?? DBNull.Value);
                        command.Parameters.AddWithValue("@city", (object?)user.City ?? DBNull.Value);
                        command.Parameters.AddWithValue("@postNumber", (object?)user.PostNumber ?? DBNull.Value);
                        command.Parameters.AddWithValue("@street", (object?)user.Street ?? DBNull.Value);
                        command.Parameters.AddWithValue("@propertyNumber", (object?)user.PropertyNumber ?? DBNull.Value);
                        command.Parameters.AddWithValue("@apartmentNumber", (object?)user.ApartmentNumber ?? DBNull.Value);
                        command.Parameters.AddWithValue("@pesel", (object?)user.Pesel ?? DBNull.Value);
                        command.Parameters.AddWithValue("@dateOfBirth", user.DateOfBirth != default ? user.DateOfBirth.ToString("yyyy-MM-dd") : DBNull.Value);
                        command.Parameters.AddWithValue("@sex", user.Sex.HasValue ? user.Sex.ToString() : DBNull.Value);
                        command.Parameters.AddWithValue("@Email", (object?)user.Email ?? DBNull.Value);
                        command.Parameters.AddWithValue("@phoneNumber", (object?)user.PhoneNumber ?? DBNull.Value);
                        command.Parameters.AddWithValue("@accessLevel", (object?)user.AccessLevel ?? DBNull.Value);
                        command.ExecuteNonQuery();
                    }

                    // Handle recovery logic
                    if (user.recovery.GetValueOrDefault(false))
                    {
                        string recoveryQuery = @"UPDATE users SET temp_password = NULL WHERE id = @userId";
                        using (var recoveryCommand = new SqliteCommand(recoveryQuery, connection))
                        {
                            recoveryCommand.Parameters.AddWithValue("@userId", userId);
                            recoveryCommand.ExecuteNonQuery();
                        }
                    }
                }
                Console.WriteLine(DateTime.UtcNow + " id: " + userId + " user data updated successfully.");
                return Ok("User data updated successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(DateTime.UtcNow + " Error during user data update: " + ex.Message);
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut("update-access-level/{userId}")]
        public IActionResult UpdateAccessLevel(int userId, [FromBody] int accessLevel)
        {
            try
            {
                using (var connection = new SqliteConnection(databasePath))
                {
                    connection.Open();
                    string query = @"UPDATE users SET access_level = @accessLevel WHERE id = @userId";
                    using (var command = new SqliteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@userId", userId);
                        command.Parameters.AddWithValue("@accessLevel", accessLevel);
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            Console.WriteLine(DateTime.UtcNow + " id: " + userId + " access level updated successfully.");
                            return Ok("Access level updated successfully.");
                        }
                        else
                        {

                            return NotFound("User not found.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(DateTime.UtcNow + " Error during access level update: " + ex.Message);
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost("recover-password")]
        public IActionResult RecoverPassword([FromBody] RecoverPasswordDto dto)
        {
            try
            {
                string tempPassword = GenerateTemporaryPassword();
                string userEmail = dto.Email;
                int affected = 0;

                using (var connection = new SqliteConnection(databasePath))
                {
                    connection.Open();
                    // Poprawiona składnia SQL (usuń przecinek przed WHERE)
                    string query = @"UPDATE users SET temp_password = @tempPassword WHERE email = @Email";
                    using (var command = new SqliteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@tempPassword", tempPassword);
                        command.Parameters.AddWithValue("@Email", userEmail);
                        affected = command.ExecuteNonQuery();
                    }
                }

                if (affected > 0)
                {
                    SendTemporaryPasswordEmail(userEmail, tempPassword);
                    return Ok("Temporary password sent to your email.");
                }
                else
                {
                    return NotFound("User with given email not found.");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        private string GenerateTemporaryPassword()
        {
            // Prosta generacja hasła tymczasowego (8 znaków)
            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var random = new Random();
            var password = new char[8];
            for (int i = 0; i < password.Length; i++)
                password[i] = chars[random.Next(chars.Length)];
            return new string(password);
        }

        private void SendTemporaryPasswordEmail(string email, string tempPassword)
        {
            // Wysyłka maila przez Gmail SMTP
            try
            {
                using (var client = new System.Net.Mail.SmtpClient("smtp.gmail.com"))
                {
                    client.Port = 587;
                    client.Credentials = new System.Net.NetworkCredential(/*passy*/);
                    client.EnableSsl = true;

                    var mail = new System.Net.Mail.MailMessage();
                    mail.From = new System.Net.Mail.MailAddress("finderofprofitablescaroffers@gmail.com");
                    mail.To.Add(email);
                    mail.Subject = "Password Recovery";
                    mail.Body = $"Your temporary password is: {tempPassword}";

                    client.Send(mail);
                    Console.WriteLine(DateTime.UtcNow + " Temporary password sent to: " + email);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(DateTime.UtcNow + " Error sending email: " + ex.Message);
            }
        }
  
    }

    public class UserDto 
    {
        public string? Login { get; set; }
        public string? Password { get; set; }
        public string? Name { get; set; }
        public string? Surname { get; set; }
        public string? City { get; set; }
        public string? PostNumber { get; set; }
        public string? Street { get; set; }
        public string? PropertyNumber { get; set; }
        public int? ApartmentNumber { get; set; }
        public string? Pesel { get; set; }
        public DateTime DateOfBirth { get; set; }
        public char? Sex { get; set; }
        public string? Email { get; set; }
        public string? PhoneNumber { get; set; }
        public bool? Forgotten { get; set; }
        public int? AccessLevel { get; set; }
        public bool? recovery { get; set; }
    }

    public class LoginDto
    {
        public string? Login { get; set; }
        public string? Password { get; set; }
    }

    public class RecoverPasswordDto
    {
        public string? Email { get; set; }
    }

    public class Program
    {
        public static void Main(string[] args)
        {
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                    webBuilder.UseUrls("https://localhost:5185");
                    //https://5sqcn5m9-5185.euw.devtunnels.ms"
                    //https://localhost:5185
                    webBuilder.ConfigureKestrel(options =>
                    {
                        options.ListenAnyIP(888);
                    });
                })
                .Build()
                .Run();
        }
    }
}
