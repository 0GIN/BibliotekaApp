﻿using System.DirectoryServices;
using System.Net.Http;
using System.Text;
using System.Text.Json;

namespace biblioteka
{
    public class DatabaseHandler
    {
        private readonly string apiBaseUrl = "http://localhost:5185"; // Update to the correct URL

        public void CreateDatabase()
        {
            using (var client = new HttpClient())
            {
                var response = client.PostAsync($"{apiBaseUrl}/create-database", null).Result;
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to create database: {response.ReasonPhrase}");
                }
            }
        }




        public void AddUser(string login, string password, string name, string surname, string city, string postNumber, string street, string propertyNumber, int apartmentNumber, string pesel, DateTime dateOfBirth, char sex, string email, string phoneNumber)
        {
            using (var client = new HttpClient())
            {
                var user = new
                {
                    Login = login,
                    Password = password,
                    Name = name,
                    Surname = surname,
                    City = city,
                    PostNumber = postNumber,
                    Street = street,
                    PropertyNumber = propertyNumber,
                    ApartmentNumber = apartmentNumber,
                    Pesel = pesel,
                    DateOfBirth = dateOfBirth,
                    Sex = sex,
                    Email = email,
                    PhoneNumber = phoneNumber
                };
                var content = new StringContent(JsonSerializer.Serialize(user), Encoding.UTF8, "application/json");
                var response = client.PostAsync($"{apiBaseUrl}/add-user", content).Result;
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to add user: {response.ReasonPhrase}");
                }
            }
        }

        public (string token, bool forgotten) Login(string login, string password)
        {
            using (var client = new HttpClient())
            {
                var loginDto = new { Login = login, Password = password };
                var content = new StringContent(JsonSerializer.Serialize(loginDto), Encoding.UTF8, "application/json");
                var response = client.PostAsync($"{apiBaseUrl}/login", content).Result;
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Login failed: {response.ReasonPhrase}");
                }
                var result = JsonSerializer.Deserialize<dynamic>(response.Content.ReadAsStringAsync().Result);
                return (result.token.ToString(), (bool)result.forgotten);
            }
        }

        public void ForgetUser(int userId)
        {
            using (var client = new HttpClient())
            {
                var response = client.PostAsync($"{apiBaseUrl}/forget-user/{userId}", null).Result;
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to forget user: {response.ReasonPhrase}");
                }
            }
        }

        public void Logout(int userId)
        {
            using (var client = new HttpClient())
            {
                var response = client.PostAsync($"{apiBaseUrl}/logout/{userId}", null).Result;
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to logout: {response.ReasonPhrase}");
                }
            }
        }

        public List<UserDetailsDto> GetAllUsers()
        {
            using (var client = new HttpClient())
            {
                var response = client.GetAsync($"{apiBaseUrl}/get-all-users").Result;
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to get all users: {response.ReasonPhrase}");
                }
                var responseContent = response.Content.ReadAsStringAsync().Result;

                // Deserializacja odpowiedzi na listę UserDetailsDto
                return JsonSerializer.Deserialize<List<UserDetailsDto>>(responseContent, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
        }

        public (int id, string login, string name, string surname, string city, string postNumber, string street, string propertyNumber, int apartmentNumber, string pesel, DateTime dateOfBirth, char sex, string email, string phoneNumber)? FindUserByLogin(string login)
        {
            using (var client = new HttpClient())
            {
                var response = client.GetAsync($"{apiBaseUrl}/find-user-by-login/{login}").Result;
                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }

                // Declare and assign responseContent
                string responseContent = response.Content.ReadAsStringAsync().Result;
                if (string.IsNullOrWhiteSpace(responseContent))
                {
                    return null; // Handle empty response
                }

                // Deserialize into UserDetailsDto
                var user = JsonSerializer.Deserialize<UserDetailsDto>(responseContent, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                if (user == null)
                {
                    return null;
                }

                return (user.Id, user.Login, user.Name, user.Surname, user.City, user.PostNumber, user.Street, user.PropertyNumber, user.ApartmentNumber ?? 0, user.Pesel, user.DateOfBirth, user.Sex ?? ' ', user.Email, user.PhoneNumber);
            }
        }

        public (int id, string login, string name, string surname, string city, string postNumber, string street, string propertyNumber, int apartmentNumber, string pesel, DateTime dateOfBirth, char sex, string email, string phoneNumber)? FindForgottenUserByLogin(string login)
        {
            using (var client = new HttpClient())
            {
                var response = client.GetAsync($"{apiBaseUrl}/find-forgotten-user-by-login/{login}").Result;
                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }

                // Declare and assign responseContent
                string responseContent = response.Content.ReadAsStringAsync().Result;
                if (string.IsNullOrWhiteSpace(responseContent))
                {
                    return null; // Handle empty response
                }

                // Deserialize into UserDetailsDto
                var user = JsonSerializer.Deserialize<UserDetailsDto>(responseContent, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                if (user == null)
                {
                    return null;
                }

                return (user.Id, user.Login, user.Name, user.Surname, user.City, user.PostNumber, user.Street, user.PropertyNumber, user.ApartmentNumber ?? 0, user.Pesel, user.DateOfBirth, user.Sex ?? ' ', user.Email, user.PhoneNumber);
            }
        }

        public (int id, string login, string name, string surname, string city, string postNumber, string street, string propertyNumber, int apartmentNumber, string pesel, DateTime dateOfBirth, char sex, string email, string phoneNumber)? FindUserById(int id)
        {
            using (var client = new HttpClient())
            {
                var response = client.GetAsync($"{apiBaseUrl}/find-user-by-id/{id}").Result;
                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }

                // Declare and assign responseContent
                string responseContent = response.Content.ReadAsStringAsync().Result;
                if (string.IsNullOrWhiteSpace(responseContent))
                {
                    return null; // Handle empty response
                }

                var user = JsonSerializer.Deserialize<UserDetailsDto>(responseContent, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                if (user == null)
                {
                    return null;
                }

                return (user.Id, user.Login, user.Name, user.Surname, user.City, user.PostNumber, user.Street, user.PropertyNumber, user.ApartmentNumber ?? 0, user.Pesel, user.DateOfBirth, user.Sex ?? ' ', user.Email, user.PhoneNumber);
            }
        }

        public void ChangeUserData(int userId, string? login = null, string? password = null, string? name = null, string? surname = null, string? city = null, string? postNumber = null, string? street = null, string? propertyNumber = null, int? apartmentNumber = null, string? pesel = null, DateTime? dateOfBirth = null, char? sex = null, string? email = null, string? phoneNumber = null, int? accessLevel = null, bool? recovery = null)
        {
            using (var client = new HttpClient())
            {
                var user = new
                {
                    Login = login,
                    Password = password,
                    Name = name,
                    Surname = surname,
                    City = city,
                    PostNumber = postNumber,
                    Street = street,
                    PropertyNumber = propertyNumber,
                    ApartmentNumber = apartmentNumber,
                    Pesel = pesel,
                    DateOfBirth = dateOfBirth?.ToString("yyyy-MM-dd"),
                    Sex = sex?.ToString(),
                    Email = email,
                    PhoneNumber = phoneNumber,
                    AccessLevel = accessLevel,
                    Recovery = recovery // Fix typo from "recivery" to "recovery"
                };
                var content = new StringContent(JsonSerializer.Serialize(user), Encoding.UTF8, "application/json");
                var response = client.PutAsync($"{apiBaseUrl}/change-user-data/{userId}", content).Result;
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to change user data: {response.ReasonPhrase}");
                }
            }
        }

        public List<UserDetailsDto> GetAllForgotten()
        {
            using (var client = new HttpClient())
            {
                var response = client.GetAsync($"{apiBaseUrl}/get-all-forgotten").Result;
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to get all users: {response.ReasonPhrase}");
                }
                var responseContent = response.Content.ReadAsStringAsync().Result;

                // Deserializacja odpowiedzi na listę UserDetailsDto
                return JsonSerializer.Deserialize<List<UserDetailsDto>>(responseContent, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
        }

        public void UpdateAccessLevel(int userId, int accessLevel)
        {
            using (var client = new HttpClient())
            {
                var content = new StringContent(JsonSerializer.Serialize(accessLevel), Encoding.UTF8, "application/json");
                var response = client.PutAsync($"{apiBaseUrl}/update-access-level/{userId}", content).Result;

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to update access level: {response.ReasonPhrase}");
                }
            }
        }
     
   
    }

    public class UserDetailsDto
    {
        public int Id { get; set; }
        public string Login { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string City { get; set; }
        public string PostNumber { get; set; }
        public string Street { get; set; }
        public string PropertyNumber { get; set; }
        public int? ApartmentNumber { get; set; }
        public string Pesel { get; set; }
        public DateTime DateOfBirth { get; set; }
        public char? Sex { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public int AccessLevel { get; set; }
    }
}